wm-gridfolio
===========

WM Gridfolio - Plugin jQuery para galeria de conteúdo estilo portfólio

## Instalação

    <link rel="stylesheet" href="jquery.wm-gridfolio-1.0.min.css">

	<script src="jquery-1.9.1.min.js"></script>
	<script src="jquery.wm-gridfolio-1.0.min.js"></script>

## Chamando o Plugin

    <script type="text/javascript">
	    $(document).ready(function(){
			$('.my-grid').WMGridfolio();
		});
    </script>

## Para mais detalhes visite a página do plugin

[Website do Plugin WM Gridfolio](http://welisonmenezes.com.br/extras/plugins/jquery/wm-gridfolio/)